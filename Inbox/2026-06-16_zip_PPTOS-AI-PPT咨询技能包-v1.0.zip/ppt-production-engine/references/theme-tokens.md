# Theme Tokens

Define visual constants before generation.

## Required Tokens

```json
{
  "font": {
    "heading": "Microsoft YaHei",
    "body": "Microsoft YaHei"
  },
  "colors": {
    "primary": "0751B8",
    "deep": "071F5C",
    "ink": "10254D",
    "muted": "4A5A78",
    "surface": "F9FCFF",
    "accent1": "F26B16",
    "accent2": "0B8B52",
    "accent3": "6B35C8"
  },
  "layout": {
    "slide_width": 13.333,
    "slide_height": 7.5,
    "margin": 0.35,
    "title_y": 0.22,
    "title_h": 0.62,
    "footer_y": 7.12,
    "grid_columns": 12,
    "gutter": 0.12
  },
  "typography": {
    "title_pt": 22,
    "subtitle_pt": 13,
    "body_pt": 10,
    "caption_pt": 6.5,
    "line_spacing_multiple": 1.1
  },
  "shape": {
    "card_radius_px": 8,
    "stroke_width": 0.75,
    "shadow": "subtle or none"
  }
}
```

## Rules

- Use semantic colors, not random colors.
- Do not change palette slide-by-slide.
- Use the same title zone unless a divider/cover layout requires otherwise.
- Prefer CJK-safe fonts for Chinese decks.
- Use accent colors for meaning: recommendation, risk, dependency, decision, or status.
- Do not use gradients as the main design system for consulting decks.
- Keep chart colors consistent across slides.

## Recommended Consulting Palettes

- `executive_blue_green`: deep blue, white/near-white, green for validated path, amber for risk.
- `boardroom_neutral`: ink, graphite, light gray, one strong accent for recommendation.
- `technology_consulting`: navy, cyan accent, green success, orange warning, violet only for AI-specific layer.
- `strategy_warm`: charcoal, off-white, muted red/orange for strategic tension, blue for structure.

Avoid decks dominated by a single purple/blue gradient, beige-only backgrounds, or random rainbow accents.
