# Layout Library

Map slide types to stable layout patterns. A good consulting deck should feel varied but controlled: repeated title/footer system, different page blueprints for different argument jobs, and enough density to be useful to executives.

## Global Grid

- Use 16:9 widescreen.
- Reserve a fixed title band and footer band except on cover/divider slides.
- Prefer a 12-column grid or equivalent coordinate system.
- Align every visible object to the grid or to another object.
- Keep repeated cards equal in size. Do not let text length resize the layout.
- Put page numbers, source notes, and confidentiality labels in stable footer zones.

## Core Layouts

- `cover`: strong title, client/context, date, optional abstract system visual or real product visual.
- `scqa_opening`: four horizontal or vertical blocks for Situation, Complication, Question, Answer.
- `executive_summary`: 3-5 conclusion cards with implication and action line.
- `section_divider`: large section title, section thesis, progress marker.
- `two_column`: left argument, right visual; use when the argument needs interpretation.
- `evidence_chart`: chart/table on 65-75% of canvas plus insight callout and source line.
- `matrix_2x2`: decision matrix with axes, quadrant labels, and highlighted recommendation.
- `option_comparison`: 3-5 options across columns; criteria rows; recommended option highlighted.
- `issue_tree`: left-to-right problem tree; use for decomposition and workplan logic.
- `hypothesis_tree`: governing hypothesis -> supporting hypotheses -> proof needed.
- `process_flow`: horizontal or vertical process with 4-8 steps, inputs/outputs, and feedback loop when relevant.
- `operating_model`: layers for strategy, governance, roles, process, data, tooling, metrics.
- `architecture`: layered boxes and arrows; use swimlanes when actors/systems differ.
- `capability_map`: grouped cards by domain with maturity/status badges.
- `maturity_model`: rows as dimensions, columns as levels, current/target markers.
- `roadmap`: time axis with phases, workstreams, milestones, dependencies, and decision gates.
- `business_case`: value levers, investment, benefits, payback, assumptions, sensitivity.
- `value_bridge`: baseline -> quantified levers -> target outcome with positive/negative deltas.
- `risk_control_matrix`: risk, impact, likelihood, mitigation, owner, trigger.
- `governance_model`: forums, decision rights, cadence, artifacts, escalation.
- `implementation_plan`: workstreams by phase with owners and near-term actions.
- `decision_page`: decision required, recommendation, alternatives, implications, approval ask.
- `appendix_evidence`: dense source table, method, assumptions, or detailed notes.

## Consulting Page Blueprints

### Executive Summary

- Top: one governing message.
- Middle: 3-5 numbered conclusion cards.
- Bottom: "decision / implication / next action" strip.
- Avoid generic cards that only summarize topics.

### Diagnosis Page

- Left: observed symptom or metric.
- Center: root cause structure, issue tree, or evidence chart.
- Right: implication for the audience.
- The title states the diagnosis, not "Current State".

### Recommendation Page

- Top: recommended path in one sentence.
- Middle: 3 reasons or criteria-backed comparison.
- Bottom: tradeoffs, prerequisites, and decision ask.
- Highlight one answer; do not make all options look equal.

### Roadmap Page

- Columns: phases or months/quarters.
- Rows: workstreams.
- Mark decision gates and dependencies.
- Add owner/metric tags when the deck is execution-oriented.

### Operating Model Page

- Use stacked layers or swimlanes.
- Include governance, roles, process, data, tools, metrics.
- Show handoffs and feedback loops with connectors.
- Keep labels short and editable.

### Business Case Page

- Combine quantitative bridge, assumption table, and executive implication.
- Separate known data from estimates.
- Put source/assumption notes in the footer.

## Visual Density Rules

- Low density: cover, divider, keynote style, single message.
- Medium density: executive summary, recommendation, comparison, roadmap.
- High density: architecture, operating model, capability map, appendix evidence.
- High-density pages need stronger alignment and smaller but readable labels; they should not become bullet dumps.

## Consulting Defaults

- Use conclusion titles.
- Keep a fixed title zone across slides.
- Use one dominant message per slide.
- Put evidence below or beside the message, not before it.
- Prefer cards, matrices, timelines, charts, process maps, and diagrams over bullet walls.
- Vary page blueprints across the deck: summary, evidence, model, comparison, roadmap, decision.
- Use icons sparingly as labels or status markers, not decoration.

## When To Delegate

If one slide becomes a dense system architecture, platform map, capability map, operating model, or end-to-end flow, delegate that slide to `editable-architecture-ppt`.
