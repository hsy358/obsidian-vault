---
name: ppt-production-engine
description: Use when slides.json, deck specs, page plans, structured slide content, PPTOS output, or consulting deck specs must be compiled into an editable PPTX with native PowerPoint objects, reusable layouts, theme tokens, charts, speaker notes, and generation scripts.
---

# PPT Production Engine / 可编辑 PPT 生产引擎

本 skill 在 `consulting-deck-os` 完成主线和页面计划之后使用，也可在已有 `slides.json`、页面计划、Markdown 结构或旧 PPT 需要更新时使用。

它是“生产编译器”，但需要有设计判断。不要重写主线，除非页面规格无法落地；如果版式选择明显弱，可以基于咨询版式库做更合理的替换。

## 1. 输入

优先输入：

- `slides.json`
- theme tokens / brand tokens
- 可选图片素材
- 可选模板 PPTX

可接受输入：

- Markdown 页面计划
- 标题 + bullet 表格
- 需要更新的已有 PPT

## 2. 输出

优先输出：

- `*-editable.pptx`
- `*-generate-deck.js` 或等价生成脚本
- 可选 `*-preview.html`
- `*-production-notes.md`，记录假设、对象策略、验证结果

## 3. 工作流

### Step 1：校验 slide spec

检查：

- deck title
- audience
- objective
- slide list
- 每页是否有 type、role、title、message、evidence、visual plan

如果标题是主题标签而不是结论式标题，先标记并尽量修正。  
如果页面规格只有“做得好看一点”而没有内容，拒绝直接生成。

### Step 2：选择 layout

- 将 slide type / role 映射到版式模式。
- 使用统一的 margin、title zone、footer zone、grid。
- 内容密度高时使用图、矩阵、架构、流程、路线图，不要堆 bullet。
- 整份 deck 要有页面节奏变化：summary、evidence、model、comparison、roadmap、decision。
- 优先使用 `references/layout-library.md`，不要临时堆卡片。

### Step 3：生成 PPTX

- 所有重要文字使用 PowerPoint 原生文本框。
- 卡片、容器、箭头、badge、连接线尽量使用 native shapes。
- 图表尽量使用 native chart；不可行时用可编辑形状和文本重建。
- 图片只用于背景、真实图片、logo、截图、生成概念图等，不承载核心文本。
- 有 speaker notes 时保留。
- 流程图和架构图使用连接线，不要画一堆互不连接的线段。
- icon 风格保持一致，不要混用多种图标体系。

### Step 4：保护可编辑性

禁止：

- 将整页扁平化成图片。
- 把重要文本放进图片。
- 用一个巨大的 SVG 承载全部内容。

必须保持可提取文本：

- 标题
- 正文
- 标签
- 数字
- 来源
- 假设
- 图表说明

如果使用 SVG / image 做视觉资产，必须在上方保留 native editable text layer。

### Step 5：验证

至少检查：

- PPTX package structure
- slide XML 是否存在
- 关键文本是否可提取
- shape / picture 数量
- 如果工具允许，渲染为图片检查重叠、裁切、层级、版式单调

## 4. 对象标准

- 标题：native text，位置一致，结论式表达。
- 正文：native text box，不能栅格化。
- 卡片/面板：native rectangle 或 rounded rectangle，圆角不要过大。
- 连接线：native line / arrow，线宽统一。
- 表格：native table 或文本 + 形状构成的可编辑表格。
- 图表：native chart 或可编辑组件重建。
- 图标：统一线性或简洁风格，只做功能标识，不做装饰堆砌。
- 来源：footer 中小字号 native text，标注 `Source:` 或 `Assumption:`。

## 5. Layout 选择规则

- `executive_summary`：用 executive summary 版式。
- `diagnosis` 且需要拆问题：用 issue tree 或 evidence chart。
- 选项对比：用 option comparison 或 matrix_2x2。
- 目标状态：用 operating model、architecture 或 capability map。
- 节奏/阶段：用 roadmap 或 implementation plan。
- 需要审批：用 decision page。
- 涉及 AI capability、platform、workflow、governance：优先考虑 operating model，不要默认卡片。
- 教育/培训：学习目标、知识结构、案例分析、课堂互动、专题小结要有不同页面形态。

## 6. 咨询视觉风格

- 使用克制对比：一个主色、一个中性背景、1-3 个语义强调色。
- 避免一整套都靠渐变撑视觉。
- 层级顺序：title -> message / callout -> visual -> source。
- 高密度页面靠分区、泳道、坐标轴、对齐来组织。
- 少用重阴影，多用细分隔线、badge、精确间距。
- 中文 deck 使用 CJK 安全字体，例如 Microsoft YaHei。

## 7. 工具

优先：

- `PptxGenJS`：适合脚本化生成可编辑 PPTX，支持 text、shape、image、table、chart。

备选：

- `python-pptx`
- Office MCP / OfficeCLI，如果可用

参考：

- `references/layout-library.md`
- `references/theme-tokens.md`
- `scripts/generate-deck-template.js`

## 8. 交付说明

交付时说明：

- PPTX 文件路径
- 生成脚本路径
- 是否使用模板
- 哪些内容为原生对象
- 是否存在图片化风险
- 验证命令和验证结果
- 未完成的渲染或人工检查限制
