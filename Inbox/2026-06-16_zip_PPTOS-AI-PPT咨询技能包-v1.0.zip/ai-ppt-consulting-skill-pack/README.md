# AI PPT Consulting Skill Pack / PPTOS

这是跨平台的咨询级可编辑 PPT 生产技能包。它不是第 6 个必须执行的 skill，而是整个 PPT 技能组合的安装说明、触发入口和跨平台路由说明。

## 统一触发词

统一使用：

```text
PPTOS
```

当用户写：

```text
PPTOS：AI 项目经理，10 页，可编辑，咨询风格
用 PPTOS 生成一份咨询级可编辑 PPT
走 PPTOS，读取这个资料目录生成汇报 PPT
```

都等价于启动完整流程：

```text
knowledge-to-deck -> consulting-deck-os -> education-training-deck when needed -> editable-architecture-ppt as needed -> ppt-production-engine -> ppt-quality-review
```

用户不需要记住单独 skill 名称。

## 包含的主 skills

请把这 6 个主 skills 和本说明包放在同一层级：

- `knowledge-to-deck`
- `consulting-deck-os`
- `education-training-deck`
- `editable-architecture-ppt`
- `ppt-production-engine`
- `ppt-quality-review`
- `ai-ppt-consulting-skill-pack`

其中 `consulting-deck-os` 内部还包含：

- `profiles/education-training.md`
- `references/content-quality-gates.md`
- `references/route-selection.md`
- `references/slide-spec.md`
- `references/system-roadmap.md`

## 推荐目录结构

```text
skills/
  ai-ppt-consulting-skill-pack/
  knowledge-to-deck/
  consulting-deck-os/
  education-training-deck/
  editable-architecture-ppt/
  ppt-production-engine/
  ppt-quality-review/
```

## 跨平台使用策略

有两种模式：

1. **Native skill mode**：平台支持 skills 自动发现时使用。
2. **Portable prompt mode**：平台不稳定支持多 skill 时使用。

优先使用 native skill mode。  
如果平台不能稳定加载多个 skill，就把 `PORTABLE_PROMPT.md` 放到项目说明或系统提示词里。

## 平台说明

### Codex

把 6 个主 skills 放到可识别的 skills 目录。用户直接说：

```text
PPTOS：基于这个主题，做一份咨询级可编辑 PPT。
```

Codex 应自动走：

```text
knowledge-to-deck -> consulting-deck-os -> education-training-deck when needed -> editable-architecture-ppt as needed -> ppt-production-engine -> ppt-quality-review
```

### Claude Code

把 6 个主 skills 放到 Claude Code 的 skills 目录。若自动触发不稳定，把 `PORTABLE_PROMPT.md` 内容放入项目说明，并告诉 Claude 这些 skill 文件夹路径。

### opencode / Hermes / 小龙虾 / 其他 Agent

如果平台没有一等的 skill loader，把 `PORTABLE_PROMPT.md` 放入系统提示词或项目说明。保留 6 个主 skill 文件夹作为本地参考，并让 Agent 按需读取。

### ChatGPT Projects / 自定义助手

上传或附加 6 个主 skill 文件夹和 `PORTABLE_PROMPT.md`，把 portable prompt 放进项目说明。

## 最短用户提示

推荐：

```text
PPTOS：[主题/资料路径]，[页数]页左右，可编辑，咨询风格。
```

示例：

```text
PPTOS：AI 项目经理，10 页左右，可编辑，咨询风格。
PPTOS：读取 D:\资料\AI转型文章，生成 15 页管理层汇报 PPT。
PPTOS：做一份高校 AI 教师培训课件，30 页左右，可讲、可投影、可编辑。
```

## 输出契约

优先产出：

- `deck-brief.md`
- `storyline.md`
- `profile-plan.md`，当领域 profile 适用时
- `slides.json`
- `slide-blueprint.md`
- `editable.pptx`
- `qa-report.md`
- `process.md`

## 质量门槛

最终 deck 必须：

- 有清晰的决策级主线。
- 使用结论式标题。
- 内容不能空、薄、套模板。
- 保持 PowerPoint 可编辑。
- 尽量使用 native text、shape、chart、connector。
- 通过 PPTX 结构检查。
- 输出 QA 报告并说明限制。
