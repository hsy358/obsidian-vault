---
name: education-training-deck
description: Use when the user wants an education PPT, courseware, teaching deck, teacher training deck, public lecture, curriculum design presentation, exam review slides, knowledge training, workshop deck, or any PPTOS task that must be teachable, learnable, projection-readable, content-rich, and editable.
---

# Education Training Deck / 教育培训课件专家

本 skill 是 PPTOS 的教育培训垂直增强 skill，用于把课程资料、教学大纲、教材章节、培训主题、公开讲座主题、考试复习内容或知识训练材料，转成“能讲、能学、能投影、可编辑”的 PPT。

它可以独立使用，也可以由 `consulting-deck-os` 在识别教育/培训场景时调度。

## 1. 何时使用

用户请求包含以下任一场景时使用：

- 高校课件、课程 PPT、教学大纲转 PPT、教材章节转 PPT
- 教师培训、AI 公开课、专题讲座、校内公开课
- 课程建设方案、教学改革汇报、学院/领导汇报
- 学生课堂学习、复习课件、考试复习、考点串讲
- 企业培训、知识培训、工作坊、内部训练营

如果用户使用 `PPTOS` 且主题明显是教育/培训，也应启用本 skill。

## 2. 核心原则

- 不只生成漂亮页面，要生成教师真正能讲、学习者真正能学的课件。
- 先判断用途和深度，再生成页面。
- 内容不能只是大纲骨架；每个重要知识点要有解释、结构、案例、互动或备注。
- 不为了内容牺牲可读性；超出投影可读范围时拆页、转图表或移入 speaker notes。
- 最终仍要进入 `ppt-production-engine` 和 `ppt-quality-review`，保持 PPTX 可编辑和可审查。

## 3. 必须读取的详细规则

执行本 skill 时，读取：

```text
references/education-deck-rules.md
```

该文件包含：

- 内容深度确认机制
- 标准授课版 / 教师备课深度版 / 公开讲座版 / 考试复习版 / 领导汇报版
- 教学主线
- 页面角色
- 教学内容增强组件库
- 内容充实度评分
- 互动题规则
- 小结页规则
- 视觉与版式规则
- 反 AI 味规则
- 事实边界
- 教育课件 QA 模板

## 4. 默认输出

优先产出：

- `profile-plan.md`
- `teaching-outline.md`
- `storyline.md`
- `slides.json`
- `speaker-notes.md`，如果讲稿或备注较多
- `editable.pptx`
- `qa-report.md`
- `process.md`

## 5. 与 PPTOS 的衔接

在 PPTOS 中，本 skill 的位置是：

```text
knowledge-to-deck
-> consulting-deck-os
-> education-training-deck
-> editable-architecture-ppt（需要知识地图/课程体系图/教学流程图时）
-> ppt-production-engine
-> ppt-quality-review
```

在 `slides.json` 中额外加入：

- `teaching_goal`
- `learner_takeaway`
- `speaker_notes`
- `interaction_design`
- `content_depth`
- `teaching_usability_score`
- `visual.layout`

## 6. 交付前门槛

不能交付以下类型的教育 PPT：

- 只有大纲，没有讲授内容。
- 每个专题都套同一个模板。
- 案例只列名字，没有分析角度。
- 互动题重复、空泛、无法课堂执行。
- 小结页模板化，没有本专题特征。
- 正文字号过小，不适合投影。
- 事实、政策编号、教材页码、专家原话未经核实却写成确定事实。
- 最终 PPTX 不可编辑或整页截图化。

交付前必须输出 QA 结果，至少包括：

- 内容完整性
- 内容深度
- 教学可讲性
- 学生可学性
- 视觉可读性
- 章节一致性
- 事实一致性
- 可编辑性
- 渲染检查状态
