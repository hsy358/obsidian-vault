---
name: consulting-deck-os
description: Use when the user wants PPTOS, a consulting-style PPT, strategy deck, client proposal, executive briefing, board report, business case, product plan, roadmap, research synthesis, courseware, training deck, or any presentation that needs strong storyline, executive logic, source-backed claims, editability, and repeatable delivery.
---

# Consulting Deck OS / 咨询级 PPT 操作系统

这是 PPTOS 的主控 skill。它不是单独的排版器，而是负责调度整套 PPT 技能组合，把主题、资料、文档或想法转成一份咨询级、可编辑、可审查的 PowerPoint。

核心原则：

```text
先主线，后页面；先证据，后表达；先可编辑，再美化。
```

默认链路：

```text
source context -> decision question -> storyline -> page architecture -> editable PPTX -> review loop
```

## 1. 输出契约

优先产出这些文件：

- `deck-brief.md`：受众、目标、约束、语气、交付格式。
- `storyline.md`：核心结论、逻辑链、证据点、建议。
- `profile-plan.md`：适用的领域 profile 和额外质量门禁。
- `slides.json`：逐页结构化规格。
- `slide-blueprint.md`：每页角色、版式选择、证据和可编辑要求。
- `preview.html`：高密度或高风险页面的可选预览。
- `editable.pptx`：最终可编辑 PowerPoint。
- `process.md`：过程、假设、验证、限制。

如果用户只需要单页复杂图，例如架构图、流程图、能力地图，则委托给 `editable-architecture-ppt`。

## 2. 工作流

### Step 1：分类 PPT

先判断这份 PPT 属于哪类：

- 战略汇报
- 客户方案
- 高管/董事会简报
- 商业计划
- 产品规划
- 路线图
- 研究综合
- 教育课件 / 培训课件
- 技术架构 / 运营模型

同时判断交付路线：

- `outbound draft`：快速草稿，用于早期讨论。
- `refinement deck`：正式交付，可编辑、可审查、需要迭代。

必须明确观众问题：

```text
观众看完这份 PPT，需要批准、选择、投资、对齐、学习、诊断，还是行动？
```

然后读取：

- `references/content-quality-gates.md`：选择内容深度和通用内容门禁。
- `profiles/education-training.md`：教育、培训、课件、公开讲座、课程建设、考试复习场景必须读取。

### Step 2：建立咨询逻辑

使用咨询表达框架：

- SCQA：Situation、Complication、Question、Answer。
- Pyramid Principle：一个 governing message，下面 3-5 个支撑论点。
- Issue tree：当主题大而模糊时，用问题树拆解。
- Evidence map：把来源资料转换为 claim、evidence、assumption、confidence。

所有重大判断都要区分：

```text
事实 / 来源观点 / 推论 / 假设 / 需核实
```

### Step 3：写 storyline

先写整份 deck 的 5-9 句话主线，再做页面。

要求：

- 从决策问题开始。
- 每个章节有明确 section message。
- 每页标题是结论，不是主题。
- 如果某页标题写不成结论，这页还没准备好。
- 用 `content-quality-gates.md` 检查是否内容偏薄、空泛、模板化。

### Step 4：做页面计划

给每页分配清晰角色：

- opener
- executive summary
- issue tree
- diagnosis
- evidence
- framework
- recommendation
- operating model
- business case
- roadmap
- risk
- decision page
- appendix

选择页面蓝图时参考：

- `references/slide-spec.md`
- `../ppt-production-engine/references/layout-library.md`

高密度内容优先使用图、矩阵、时间轴、流程、模型、图表，不要堆 bullet。

教育/培训 deck 必须额外包含：

- teaching goal
- learner takeaway
- interaction design
- speaker notes

### Step 5：选择生产路线

- 咨询交付、多页可编辑 PPT：生成结构化 `slides.json`，交给 `ppt-production-engine`。
- 单页复杂系统图：委托 `editable-architecture-ppt`。
- 视觉冲击型公开演讲：可以生成视觉资产，但标题、正文、图表和数据仍保持可编辑。

### Step 6：生成并审查

默认生成可编辑 PPTX。

交付前必须：

- 检查 PPTX 包结构。
- 提取文本确认核心内容可编辑。
- 检查 shape / picture 数量。
- 如果工具允许，渲染为图片或 PDF 检查版式。
- 使用 `ppt-quality-review` 输出 QA。

## 3. 工作规则

- 使用结论式标题，不使用空泛主题标题。
- 每页只承载一个主要信息。
- 分清逻辑、证据和视觉表达。
- 默认追求可编辑，而不是整页截图化。
- 不要把“好看”等同于“好 deck”。真正的产品是主线和判断。
- 重要页面先写 "so what"，再放证据。
- 咨询交付优先 12-18 页高质量页面，而不是 30 页浅内容。
- 不接受“看起来完整但没内容”的页面。

## 4. 常见主线模式

选择一个主模式，不要混用过多：

- **诊断到建议**：现状问题 -> 根因 -> 选项 -> 推荐 -> 路线图。
- **机会到运营模型**：市场/技术变化 -> 战略选择 -> 能力体系 -> 执行计划。
- **商业案例**：基线 -> 价值杠杆 -> 投入 -> 回报 -> 风险和决策。
- **转型方案**：目标 -> 成熟度差距 -> 目标状态 -> 工作流 -> 节奏。
- **供应商/产品选择**：标准 -> 选项 -> 评分 -> 推荐 -> 落地。
- **研究综合**：关键发现 -> 影响 -> 选择 -> 行动建议。
- **教育培训**：为什么学 -> 学什么 -> 怎么理解 -> 怎么应用 -> 怎么讨论 -> 怎么总结。

## 5. 页面质量门槛

每页进入生产前必须回答：

- **Role**：这页在论证中承担什么任务？
- **Takeaway**：观众看完应该相信什么？
- **Evidence**：有什么来源、观察、估算或假设支撑？
- **Visual form**：为什么用矩阵、图表、路线图、流程、模型或总结页？
- **Editability**：哪些元素必须保持原生文本、形状、图表或连接线？

## 6. 组合调度

- 有资料来源时，先用 `knowledge-to-deck`。
- 有复杂架构图、流程图、能力地图、系统图时，用 `editable-architecture-ppt`。
- 需要生成最终 PPTX 时，用 `ppt-production-engine`。
- 交付前，用 `ppt-quality-review`。

## 7. Domain Profiles

Profiles 用于增加垂直行业深度，不替代主控：

- `profiles/education-training.md`：教育、课件、教师培训、公开讲座、课程建设、考试复习、知识培训；该 profile 会调度独立 skill `education-training-deck`。

启用 profile 时，创建 `profile-plan.md`，写明：

- trigger reason
- selected depth mode
- required page roles
- extra content gates
- visual constraints
- QA checks

如果 profile 指向独立 skill，例如 `education-training-deck`，必须继续读取并执行该独立 skill，而不是只停留在 profile 摘要。

## 8. 常见失败模式

- 先做美化，再想逻辑。
- 每页都做成图，却没有论证。
- PPT 很漂亮，但不可编辑。
- 标题是主题，不是结论。
- 只是想法合集，不是建议。
- 泛泛使用 AI 词汇，没有具体机制。
- 连续多页都是同一种卡片布局。
- 明明是教育/培训场景，却没有启用教育 profile。
