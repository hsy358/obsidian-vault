# Content Quality Gates

Use these gates for every serious deck, regardless of industry. They adapt the strongest ideas from the education PPT skill into general consulting delivery: avoid thin content, empty AI language, unsupported claims, and repetitive template pages.

## Depth Gate

Before slide production, classify the expected depth:

- `outline`: fast structure, early discussion, not delivery-ready.
- `standard`: normal consulting or training deck; enough explanation, examples, and implications to present.
- `executive`: board/client/leadership deck; concise but evidence-backed, decision-oriented, no filler.
- `deep_workshop`: teaching, training, implementation, or workshop deck; includes exercises, speaker notes, and examples.
- `appendix_heavy`: detailed evidence, data, assumptions, and backup material.

If the user asks to "directly generate", default to `standard` unless context clearly requires `executive` or an education profile requires `standard_teaching`.

## Thin Content Signals

A slide is thin if two or more are true:

- only abstract bullets, no mechanism or explanation
- uses nouns without relationships or implications
- has a framework but no "so what"
- has a case/example name but no analysis
- has a recommendation without tradeoff, evidence, or next action
- repeats the same point as nearby slides
- looks visually complete but cannot support a 1-2 minute explanation
- contains generic wording that would fit any company/topic

Thin slides should be rewritten, enriched, split, or moved to appendix.

## Content Sufficiency Score

Score each important slide 1-5 on:

- `concept_clarity`: are key terms explained clearly?
- `logic`: are causes, hierarchy, tradeoffs, or relationships explicit?
- `evidence`: are claims backed by sources, observations, examples, or assumptions?
- `audience_value`: does the page answer what the audience cares about?
- `actionability`: does the page imply a decision, action, learning, or next step?

Any important slide below 3 on two dimensions needs another pass.

## Anti-Slop Rules

Avoid empty phrases unless followed by concrete mechanism, object, or metric:

- empower / enable / transform / reshape
- deep integration / comprehensive upgrade
- ecosystem / closed loop / flywheel
- efficiency improvement / quality improvement
- AI-native / intelligent / smart
- sustainable / scalable / end-to-end

Replace vague claims with:

- who changes behavior
- what workflow changes
- what decision improves
- what metric or observable outcome changes
- what capability must be built
- what risk or tradeoff remains

## Data And Fact Rules

- Do not invent percentages, survey results, market sizes, policy numbers, textbook pages, quotes, or named case facts.
- Label uncertain information as assumption, estimate, or needs verification.
- Put source or assumption notes in the footer or appendix.
- If exact data is unavailable, use qualitative comparison, scenario ranges, or clearly labeled placeholders.

## Repetition Gate

Flag the deck if:

- three consecutive content slides use the same card grid
- every slide has the same three-column structure
- section summaries use identical wording
- examples are named but not analyzed
- all recommendations sound interchangeable

Fix by changing page roles: evidence chart, issue tree, operating model, comparison matrix, roadmap, decision page, case analysis, or appendix evidence.

## Speaker Value Gate

Ask for each important slide:

- What will the presenter say beyond reading the text?
- What question might the audience ask?
- What evidence or example supports the point?
- What should happen after this slide?

If these cannot be answered, the slide is not ready for final PPT generation.
