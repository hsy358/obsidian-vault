# Slide Spec Reference

Use `slides.json` to make deck generation repeatable.

The spec is both a content contract and a production contract. It should tell the agent what the slide argues, what evidence supports it, what visual blueprint to use, and which objects must remain editable.

## Minimal Schema

```json
{
  "deck_title": "AI Native Education Platform Strategy",
  "audience": "executives / investors / client team",
  "objective": "decision the deck should support",
  "decision_question": "What should the audience decide after reading this deck?",
  "governing_message": "One sentence answer to the decision question",
  "style": {
    "tone": "consulting / executive / technical / product",
    "palette": "enterprise blue",
    "editability": "native-pptx"
  },
  "storyline": {
    "scqa": {
      "situation": "stable context",
      "complication": "change, risk, opportunity, or constraint",
      "question": "decision question",
      "answer": "recommended answer"
    },
    "sections": [
      {
        "name": "Diagnosis",
        "message": "Section-level takeaway",
        "slide_range": "3-6"
      }
    ]
  },
  "slides": [
    {
      "slide_no": 1,
      "type": "cover",
      "role": "opener / diagnosis / evidence / recommendation / roadmap / risk / decision",
      "title": "Conclusion-style action title",
      "message": "One sentence key point",
      "so_what": "Why this matters to the audience",
      "content": ["short point 1", "short point 2"],
      "evidence": [
        {
          "claim": "Claim supported on this page",
          "source": "path, citation, interview, estimate, or assumption",
          "confidence": "high / medium / low"
        }
      ],
      "visual": {
        "kind": "hero / matrix / flow / architecture / chart / roadmap / issue_tree / operating_model",
        "layout": "layout key from layout-library.md",
        "description": "what the page should show",
        "objects": ["native text", "shapes", "connectors", "chart", "icons"],
        "asset_prompt": "optional image prompt; avoid embedded text"
      },
      "density": "low / medium / high",
      "editability": "native text and shapes; no flattened slide image",
      "notes": "speaker notes or delivery intent"
    }
  ]
}
```

## Common Slide Types

- `cover` - title, client/context, date.
- `executive_summary` - 3-5 conclusions.
- `scqa_opening` - situation, complication, question, answer.
- `issue_tree` - problem decomposition.
- `current_state` - diagnosis and evidence.
- `opportunity` - market or business opening.
- `solution_overview` - recommended answer.
- `architecture` - system or operating model.
- `capability_map` - grouped capabilities.
- `process_flow` - lifecycle or workflow.
- `comparison` - options, tradeoffs, vendor/product comparison.
- `maturity_model` - current vs target maturity across dimensions.
- `operating_model` - roles, governance, workflow, data, tooling.
- `roadmap` - phases, milestones, dependencies.
- `business_case` - value, cost, benefit.
- `value_bridge` - baseline to target value movement.
- `risk_governance` - risks, controls, owners.
- `decision_page` - decision needed, options, recommendation, next action.
- `next_steps` - actions, owners, dates.
- `appendix` - supporting evidence.

## Title Rule

Bad: `Market Trends`

Good: `AI-native workflows are shifting budget from tools to operating systems`

Each title should answer: "What should the audience believe after seeing this slide?"

## Page Role Rules

- `executive_summary`: 3-5 conclusion blocks; each block includes implication and action, not only description.
- `issue_tree`: branches should be mutually distinct and collectively cover the problem enough for decision-making.
- `evidence`: show chart/table/source-backed proof; title states the conclusion from the evidence.
- `recommendation`: make the answer explicit; include rejected alternatives or tradeoffs when important.
- `roadmap`: sequence phases with owners, milestones, dependencies, and decision gates.
- `risk_governance`: pair each risk with mitigation, owner, trigger, and review cadence.
- `decision_page`: make it obvious what the audience must approve, choose, or fund.

## Anti-Patterns

- Topic-only titles.
- Slide content with no source, assumption, or reasoning.
- Repeating the same card grid on many slides.
- Page specs that say "beautiful layout" without specifying visual logic.
- Important text embedded in images.
