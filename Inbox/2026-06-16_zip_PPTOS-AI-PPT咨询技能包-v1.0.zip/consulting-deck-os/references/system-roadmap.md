# Consulting Deck OS Roadmap

Current skill family:

- `consulting-deck-os` - deck strategy, storyline, slide planning, route selection.
- `knowledge-to-deck` - source inventory, evidence extraction, deck-ready context.
- `ppt-production-engine` - compile `slides.json` into editable PPTX.
- `ppt-quality-review` - review content logic, editability, visual quality, and delivery readiness.
- `editable-architecture-ppt` - dense one-page diagrams and editable architecture visuals.

Shared references and profiles:

- `references/content-quality-gates.md` - depth mode, thin-content checks, anti-slop rules, data/fact rules.
- `profiles/education-training.md` - education, courseware, training, public lecture, curriculum, and exam review profile.

## Recommended Execution Order

1. Use `knowledge-to-deck` when source material exists.
2. Use `consulting-deck-os` to define deck type, depth mode, domain profile, storyline, and slide plan.
3. Apply `references/content-quality-gates.md` before production so the deck is not thin or generic.
4. Apply `profiles/education-training.md` when the deck is for education, training, courseware, public lectures, curriculum design, or exam review.
5. Use `editable-architecture-ppt` for dense visual pages.
6. Use `ppt-production-engine` to compile the editable PPTX.
7. Use `ppt-quality-review` before claiming delivery readiness.

## Combination Principle

The deck OS is the orchestrator. Profiles should not replace it. Profiles add domain-specific depth and QA gates, while `ppt-production-engine` and `ppt-quality-review` preserve the editable delivery loop.
