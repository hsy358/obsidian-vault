# Education Training Profile / 教育培训路由 Profile

本文件是 `consulting-deck-os` 内部的轻量路由 profile。完整教育课件能力已经拆到独立 skill：

```text
../education-training-deck/SKILL.md
../education-training-deck/references/education-deck-rules.md
```

## 何时启用

当用户请求包含以下任一场景时，启用本 profile，并调度 `education-training-deck`：

- 高校课件、课程 PPT、教学大纲转 PPT、教材章节转 PPT
- 教师培训、AI 公开课、专题讲座、校内公开课
- 课程建设方案、教学改革汇报、学院/领导汇报
- 学生课堂学习、复习课件、考试复习、考点串讲
- 企业培训、知识培训、工作坊、内部训练营

## 路由动作

创建 `profile-plan.md`，至少写明：

```text
启用 profile：education-training
调度 skill：education-training-deck
使用场景：
受众：
内容深度：
教学主线：
页面角色：
需要增强的内容：
特殊 QA：
```

然后读取并执行：

```text
education-training-deck/SKILL.md
education-training-deck/references/education-deck-rules.md
```

## 默认深度

如果用户没有说明深度，也没有要求先确认，默认：

```text
场景：标准课堂授课版
深度：标准增强
结构：每个专题至少包括概念解释、核心知识结构、案例、互动、小结
风格：高校讲座课件 + 咨询式结构 + 教师可讲性
```

如果用户说“不要问，直接做”，不要阻塞，直接使用默认深度。

## PPTOS 链路

```text
knowledge-to-deck
-> consulting-deck-os + education-training profile
-> education-training-deck
-> editable-architecture-ppt（需要知识地图/课程体系图/教学流程图时）
-> ppt-production-engine
-> ppt-quality-review
```

## 额外 QA 门槛

教育/培训 deck 必须额外检查：

- 内容是否只是大纲骨架？
- 每个重点专题是否有概念解释、案例、互动、小结？
- 教师是否能用页面讲 2-3 分钟？
- 学习者是否能理解、记忆、讨论或应用？
- 互动题是否结合主题，而非模板化？
- 正文、图表、页脚是否适合投影阅读？
- 讲稿是否放入 speaker notes，而不是塞进正文？
- 是否存在未经核实的数据、教材页码、政策编号、专家原话？
