---
name: ppt-quality-review
description: Use when a PPTX, deck, slide image, generated presentation, consulting deck, PPTOS output, or editable PowerPoint must be reviewed for storyline quality, content sufficiency, editability, visual layout, text overflow, rendering issues, source coverage, and delivery readiness.
---

# PPT Quality Review / PPT 质量审查

本 skill 在声明 PPT 完成之前必须使用，尤其适用于咨询 deck、管理层汇报、客户方案、教育培训课件、可编辑 PPTX 和 PPTOS 输出。

目标是抓住 AI 生成 PPT 最容易隐藏的问题：

- 主线弱
- 内容薄
- 标题不是结论
- 证据不足
- 页面不可编辑
- 文字溢出或重叠
- 版式单调
- 风格不一致
- 事实或数据未经核实

## 1. 审查层级

### 1.1 Storyline Review

检查：

- 是否回答了观众的决策问题或学习问题？
- 是否有清晰的 governing message？
- 章节之间是否有逻辑推进？
- 每页标题是否是结论式标题？
- 每页是否只有一个主要观点？
- 是否有开场、诊断、答案、落地和收束？
- section transition 是否足够清楚？

### 1.2 Content Review

检查：

- 关键 claim 是否有来源、证据、假设或推论标注？
- 数字、人名、日期、政策、术语是否可信？
- 是否有重复页面或重复观点？
- 是否只是大纲骨架？
- 是否只有抽象 bullet，没有机制、例子、影响或行动？
- 是否有泛泛 AI 词汇，放到任何主题都能用？
- 如果使用了 domain profile，是否通过 profile-specific content gates？

### 1.3 Editability Review

检查：

- 能否从 PPTX XML 中提取核心文字？
- native shapes 和 pictures 数量是否合理？
- 是否出现整页截图化？
- 标题、正文、标签、图表数值、来源是否为 native object？
- 重要论点是否被困在截图或扁平 SVG 里？

### 1.4 Visual Review

检查：

- 对齐、间距、边距、层级、色彩是否一致？
- 是否有文字裁切、重叠、过度换行、低对比？
- 页面节奏是否变化，还是连续卡片网格？
- 高管读者是否能 3-5 秒扫出主旨？
- 教育/培训 deck 是否投影可读？
- 讲稿是否放在备注，而不是塞进正文？

### 1.5 Delivery Review

检查：

- 输出文件是否存在？
- 过程文档是否说明假设和限制？
- 未解决问题是否清楚告知用户？
- 这份 deck 是否像咨询交付，而不是模板练习？

## 2. 必须报告的证据

交付前至少报告：

- PPTX path 和 file size
- slide count
- text extraction status
- shape / picture count 或比例
- rendering status：passed / failed / unavailable，并说明原因
- remaining risks
- storyline score
- content sufficiency score
- editability score
- layout richness score
- executive readability score
- anti-slop status

## 3. PowerShell PPTX 结构检查

```powershell
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip=[System.IO.Compression.ZipFile]::OpenRead((Resolve-Path .\deck.pptx))
$slides=$zip.Entries | Where-Object { $_.FullName -match '^ppt/slides/slide[0-9]+\.xml$' }
$slides.Count
$zip.Dispose()
```

## 4. 常见问题分级

- `P1`：要求可编辑但页面被扁平化成图片。
- `P1`：关键标题、图表文字或正文被裁切。
- `P1`：整份 deck 没有 governing message 或决策问题。
- `P2`：标题是主题标签，不是结论。
- `P2`：重大 claim 缺少来源或假设说明。
- `P2`：页面看起来完整，但缺少机制、例子、影响或行动。
- `P2`：泛泛 AI 词汇没有具体对象、指标、流程或取舍。
- `P2`：连续页面版式重复，deck 显得单薄。
- `P3`：轻微对齐、间距、色彩不一致。
- `P3`：高管可读性或投影可读性低于预期。

## 5. Scorecard

每个维度 1-5 分：

- `storyline`：是否有决策问题、核心结论和章节逻辑。
- `titles`：标题是否结论化并推动论证。
- `evidence`：关键 claim 是否有来源、证据或明确假设。
- `content_sufficiency`：是否有解释、机制、例子、影响或行动。
- `layout_richness`：页面类型是否丰富且匹配内容任务。
- `editability`：标题和论点文字是否保持 native object。
- `readability`：目标受众能否快速扫出主旨和下一步。

如果任何关键维度低于 3 分，不能直接声称交付完成，必须说明风险或继续迭代。

## 6. Profile-Specific Review

如果存在 `profile-plan.md`，必须按 profile 审查。

教育/培训 deck 额外评分：

- `teaching_usability`：教师能否基于页面讲解，而不是只读文字？
- `learner_value`：学习者是否能理解、记忆、讨论或应用？
- `interaction_quality`：互动是否结合主题，而不是模板化讨论？
- `projection_readability`：正文、图表、导航是否适合投影阅读？
- `content_depth`：是否覆盖概念、结构、案例、互动、小结？

## 7. 反 AI 味检查

标记以下问题：

- “全面赋能、深度融合、生态闭环、提质增效、智慧升级”等词没有具体机制。
- 每页都使用相同三栏卡片。
- 案例只列名字，没有分析角度。
- 小结页套模板，没有本专题特征。
- 强视觉页只有装饰，没有帮助理解。
- 数据、政策编号、专家原话、教材页码未经核实。

## 8. QA 报告格式

```text
QA Report

总体评价：通过 / 需修正 / 需用户确认

Storyline：1-5
Titles：1-5
Evidence：1-5
Content Sufficiency：1-5
Layout Richness：1-5
Editability：1-5
Readability：1-5

结构检查：
- PPTX 路径：
- 页数：
- 文本提取：
- shape 数：
- picture 数：
- 渲染检查：

发现的问题：
1. ...

已修正的问题：
1. ...

仍需确认：
1. ...

交付风险：
1. ...
```
