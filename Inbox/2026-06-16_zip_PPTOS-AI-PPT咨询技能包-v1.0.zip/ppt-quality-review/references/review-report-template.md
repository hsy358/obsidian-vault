# PPT Review Report Template

```markdown
# PPT Quality Review

## Summary

- Deck:
- Slides:
- Editable text extraction:
- Shape count:
- Picture count:
- Rendering QA:
- Storyline score:
- Evidence score:
- Layout richness score:
- Editability score:
- Executive readability score:

## Findings

### P1 Critical

- None / list issues

### P2 Important

- None / list issues

### P3 Polish

- None / list issues

## Storyline Notes

- Decision question:
- Governing message:
- Main argument:
- Weak transitions:
- Missing evidence:
- Slides with topic titles:
- Slides that feel thin:

## Editability Notes

- Full-page image risks:
- Non-extractable text:
- Elements that should be native objects:

## Visual Notes

- Layout variety:
- Repeated patterns:
- Overlap/clipping:
- Pages needing richer consulting blueprint:

## Recommended Iteration

- Rewrite:
- Add evidence:
- Change layout:
- Regenerate:
- Manual review needed:

## Verification Evidence

- Commands run:
- Outputs observed:
- Limitations:
```
